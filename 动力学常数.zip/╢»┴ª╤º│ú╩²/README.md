### 文件说明

- `km_kcat_info.txt`：每行内容从左到右为 ec、底物描述、种属、km列表、kcat列表
- `ph_temp_info.txt`：每行内容从左到右为 ec、种属、最适温度列表、最适ph列表